"""Termux Native Integration Package"""
__version__ = "14.0.0"
